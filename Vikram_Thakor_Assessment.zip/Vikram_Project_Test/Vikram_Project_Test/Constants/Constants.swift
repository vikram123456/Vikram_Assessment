//
//  Constants.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class Constants{

    //Base URL:
    static let baseURL = "https://api.giphy.com/v1/gifs/"
    
    //Authorization Keys:
    static let APIKey = "GHNMHbihQ8DD5ekMUeRwf8LLUC7i539h"
    
    //Request Methods:
    static let trending = "trending"
    static let search = "search"

    //Parameters:
    static let ts = "ts"
    static let apikey = "api_key"
    static let limit = "limit"
    static let rating = "rating"
    static let q = "q"

    //Extensions:
    static let GIF = "gif"
    
    //Extensions:
    static let DIRECTORY_EMPTY = "DIRECTORY_EMPTY"
    
    //Request Header Values:
    static let GET = "get"
    static let POST = "post"
    static let Header_AcceptValue = "application/json"
    static let Header_AcceptType = "Accept"
     
}

extension Data {
    var html2AttributedString: NSAttributedString? {
        do {
            return try NSAttributedString(data: self, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding: String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            print("error:", error)
            return  nil
        }
    }
    var html2String: String { html2AttributedString?.string ?? "" }
}

extension StringProtocol {
    var html2AttributedString: NSAttributedString? {
        Data(utf8).html2AttributedString
    }
    var html2String: String {
        html2AttributedString?.string ?? ""
    }
}
