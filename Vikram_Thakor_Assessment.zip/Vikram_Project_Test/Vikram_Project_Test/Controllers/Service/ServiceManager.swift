//
//  ServiceManager.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class ServiceManager{
    
    public static var shared = ServiceManager()
    
    //MARK: Webservice Methods
    func callWebService<T:Decodable>(strMethod:String,strExtraParam : String, decodable : T.Type, result:@escaping(Result<T,Error>) -> Void) {
        var urlRequest = URLRequest(url: URL(string: Helper.getFinalURL(strMethod: strMethod,strExtraParam: strExtraParam))!)
        let session = URLSession.shared
        urlRequest.httpMethod = Constants.GET
        urlRequest.addValue(Constants.Header_AcceptValue, forHTTPHeaderField: Constants.Header_AcceptType)
        session.dataTask(with: urlRequest) {(data, res, error) in
            do{
                if data == nil && error != nil {
                    result(.failure(error!))
                }
                let object = try JSONDecoder().decode(decodable, from:data!)
                result(.success(object))
            }catch{
                print(error)
                result(.failure(error))
            }
        }.resume()
    }
    
    
}
