//
//  APIManager.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class APIManager {
       public static let shared = APIManager()
       public func getData(strExtraParam: String, success : @escaping((GIFMainData)-> Void), fail: @escaping(() -> Void)){
          let strSelectedMethod = strExtraParam.isEmpty ? Constants.trending : Constants.search
           ServiceManager.shared.callWebService(strMethod: strSelectedMethod,strExtraParam: strExtraParam, decodable: GIFMainData.self) { (result) in
               print(result)
               switch result {
               case .success(let res):
                   success(res)
               case .failure(_):
                   fail()
               }
           }
     }
}
