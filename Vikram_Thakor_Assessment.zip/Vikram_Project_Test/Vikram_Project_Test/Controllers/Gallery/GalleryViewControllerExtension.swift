//
//  ViewControllerExtension.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation
import UIKit
 

extension GalleryViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate{
 
    //MARK: - CollectionView Delegate Methods
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GalleryCollectionViewCell", for: indexPath)
        as! GalleryCollectionViewCell
        if arrImageData.count > 0 {
            cell.buttonFavorite.tag = indexPath.row
            cell.buttonFavorite.addTarget(self, action: #selector(buttonFavoriteClicked(_:)), for: .touchUpInside)
            cell.setUpCellUI(cell: cell, objFileData: arrImageData[indexPath.row], indexpath: indexPath)
            if arrFavoritesImageNames.count > 0 {
                var strFileNameFav = arrImagesNames[indexPath.row]
                print(strFileNameFav)
                print( arrFavoritesImageNames.contains(strFileNameFav))
                cell.buttonFavorite.tintColor  =  arrFavoritesImageNames.contains(strFileNameFav) ?   UIColor.red :  UIColor.white
                cell.buttonFavorite.isHidden = searchbar.text?.count ?? 0 > 0 ? true : false
            }else{
                cell.buttonFavorite.tintColor = .white
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width, height: 270)
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImageData.count
    }
 
    
    //MARK: - Custom Action Methods
    @IBAction  func buttonFavoriteClicked(_ btn: UIButton) {
        let urlFilePath = URL(string: (arrImageData[btn.tag].fileName ?? ""))
        _ =     Helper.getDocDirPath("Favorites", fileName: urlFilePath?.lastPathComponent ?? "")
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        let documentDirectory = URL(fileURLWithPath: path)
        let strFolderName = searchbar.text?.count ?? 0 > 0 ? "Search" : "GifFiles"
        let isSearch = searchbar.text?.count ?? 0 > 0 ? true : false
        let strSource = String(format: "%@/%@",strFolderName,urlFilePath?.lastPathComponent ?? "")
        let strDest = String(format: "Favorites/%@",urlFilePath?.lastPathComponent ?? "")
        let originPath = documentDirectory.appendingPathComponent(strSource)
        let destinationPath = documentDirectory.appendingPathComponent(strDest)
        do {
            try FileManager.default.copyItem(at: originPath, to: destinationPath)
             self.arrFavoritesImageNames = Helper.getImagesFromLocalDirectory(true,isSearch: false).1
        } catch {
            print(error)
            if (error.localizedDescription.range(of: "same name already exists.") != nil) {
                try! FileManager.default.removeItem(at: destinationPath)
                 self.arrFavoritesImageNames = Helper.getImagesFromLocalDirectory(true,isSearch: isSearch).1
            }
        }
        collectionViewHome.reloadData()
    }
    
    @objc func searchCrossClicked(){
            self.reloadOriginalData()
     }
 
    //MARK: - SearchBar Delegate Methods
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchbar.resignFirstResponder()
        if (searchbar.text?.count ?? 0 > 0){
            self.searchGallery()
        }
    }
 
}



extension GalleryViewController{
    
    //MARK: - Custom Methods
    func  getGifFilesFromServer()  {
        APIManager.shared.getData(strExtraParam: "") { [self] res in
            print(res)
            objGIFData = res.data
            DispatchQueue.main.async {
                if UserDefaults.standard.object(forKey: "GIFDATA") != nil {
                    self.arrImageData = Helper.getImagesFromLocalDirectory(false,isSearch: false).0
                     self.arrImagesNames = Helper.getImagesFromLocalDirectory(false,isSearch: false).1
                    self.arrFavoritesImageNames = Helper.getImagesFromLocalDirectory(true,isSearch: false).1
                    self.arrImageDataOriginal = self.arrImageData
                    self.arrImagesNamesOriginal = self.arrImagesNames
                    self.arrFavoritesImageNamesOriginal = self.arrFavoritesImageNames
                    self.collectionViewHome.reloadData()
                }else{
                    self.arrImageData.removeAll()
                    self.arrImageDataOriginal.removeAll()
                     self.saveImagesToLocalDirectory(isSearch: false)
                }
            }
        } fail: {
            print("Failed")
        }
    }
    
    func searchGallery(){
        APIManager.shared.getData(strExtraParam: searchbar.text ?? "") { [self] res in
            print(res)
            objGIFData = res.data
            DispatchQueue.main.async {
                    self.arrImageData.removeAll()
                    self.saveImagesToLocalDirectory(isSearch: true)
            }
        } fail: {
            print("Failed")
        }
     }
 
     func saveImagesToLocalDirectory(isSearch : Bool){
        self.nCountImages = 0
        for objGifData in objGIFData! {
            do {
                 let fileName =  (objGifData.id ?? "") + ".gif"
                let folderName = isSearch ? "Search" : "GifFiles"
                let fileURL = Helper.getDocDirPath(folderName, fileName: fileName)
                getData(from: URL(string: (objGifData.images?.original?.url) ?? "") ?? URL(fileURLWithPath: "")) { data, res, error in
                    guard let data = data, error == nil else {return}
                    do{
                        try! data.write(to: (fileURL))
                        let dataGIFImage = try! Data(contentsOf: URL(fileURLWithPath: fileURL.path ))
                        let image = UIImage.gifImageWithData(dataGIFImage)
                        let objFileData = FileData(image: image ?? UIImage(), fileName: fileName)
                        let isAlreadyHaving = self.arrImageData.contains(where: {$0.fileName == fileName})
                        if !isAlreadyHaving {
                            self.arrImageData.append(objFileData)
                            self.arrImagesNames.append(fileURL.lastPathComponent)
                        }
                        self.nCountImages = self.nCountImages + 1
                        if self.nCountImages == self.objGIFData?.count {
                            print("-----All Done-------")
                                self.arrFavoritesImageNames = Helper.getImagesFromLocalDirectory(true,isSearch: false).1
                           
                            UserDefaults.standard.set("GifImages", forKey: "GIFDATA")
                            UserDefaults.standard.synchronize()
                        }
                        DispatchQueue.main.async {
                             self.collectionViewHome.reloadData()
                        }
                    }
                }
            }
        }
    }
    
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
         URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
     }
    
    
    func reloadOriginalData(){
        self.arrImageData.removeAll()
        self.arrImagesNames.removeAll()
        self.arrFavoritesImageNames.removeAll()
        self.arrImageData = self.arrImageDataOriginal
        self.arrImagesNames = self.arrImagesNamesOriginal
        self.arrFavoritesImageNames = Helper.getImagesFromLocalDirectory(true,isSearch: false).1
        DispatchQueue.main.async {
            self.collectionViewHome.reloadData()
        }
    }

}
 


extension GalleryViewController : UITextFieldDelegate{
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        self.reloadOriginalData()
            return true
        }
}

