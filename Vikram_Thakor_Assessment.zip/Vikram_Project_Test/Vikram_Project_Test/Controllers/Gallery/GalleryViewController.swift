//
//  ViewController.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import UIKit

class GalleryViewController: UIViewController {
    @IBOutlet weak var collectionViewHome: UICollectionView!
    @IBOutlet weak var searchbar: UISearchBar!
    var objGIFData : [GIFData]?
     var arrImageData = [FileData]()
     var arrFavoritesImageNames = [String]()
     var arrImagesNames = [String]()
    var arrImageDataOriginal = [FileData]()
    var arrFavoritesImageNamesOriginal = [String]()
    var arrImagesNamesOriginal = [String]()

    var nCountImages = 0
    
    //MARK: View LifeCycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
   }
    
    //MARK: Custom Methods
    func setupUI(){
        searchbar.searchTextField.delegate = self
        self.getGifFilesFromServer()
    }

}



 

