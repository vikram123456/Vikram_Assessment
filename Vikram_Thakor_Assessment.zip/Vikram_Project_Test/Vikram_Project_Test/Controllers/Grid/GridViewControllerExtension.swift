//
//  ViewControllerExtension.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation
import UIKit
 

extension GridViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    //MARK: - CollectionView Delegate Methods
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GridCollectionViewCell", for: indexPath)
        as! GridCollectionViewCell
        if arrImageData.count > 0 {
            cell.buttonFavorite.tag = indexPath.row
            cell.imageViewProfile.contentMode =  self.isGridSelected ? .scaleAspectFill : .scaleToFill
            cell.setUpCellUI(cell: cell, objFileData: arrImageData[indexPath.row], indexpath: indexPath)
        }
        return cell
    }
     
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrImageData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if !isGridSelected {
            return CGSize(width: collectionView.frame.size.width, height: 270)
        }
        if indexPath.row % 3 ==  0 && indexPath.row != 0{
             return CGSize(width: collectionView.frame.width/5, height: 120)
        }else{
            return CGSize(width: collectionView.frame.width/4, height: 120)
         }
    }
 

    
}
