//
//  ViewController.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import UIKit

class GridViewController: UIViewController {
  
 
    @IBOutlet weak var collectionViewHome: UICollectionView!
    var isGridSelected = true
    var arrImageData = [FileData]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.arrImageData = Helper.getImagesFromLocalDirectory(true,isSearch: false).0
        collectionViewHome.reloadData()
    }


    @IBAction func segmentClicked(_ sender: Any) {
        let segmentedControl = sender as! UISegmentedControl
        switch segmentedControl.selectedSegmentIndex {
        case 0:
            isGridSelected = true
        default:
            isGridSelected = false
        }
        collectionViewHome.reloadData()
    }
}

