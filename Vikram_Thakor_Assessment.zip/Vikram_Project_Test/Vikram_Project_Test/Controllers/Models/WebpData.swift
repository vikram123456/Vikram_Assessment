//
//  File.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class WebpData : Decodable{
 let height: String?
 let width: String?
 let size: String?
 let url:String?
 let webp_size: String?
 let webp:String?
}
