//
//  Images.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation


class Images : Decodable {
    let original: ImageData?
    let downsized: ImageSizeData?
    let downsized_large: ImageSizeData?
    let downsized_medium: ImageSizeData?
    let downsized_small : ImageSizeData?
    let downsized_still : ImageSizeData?
    let fixed_height : MP4Data?
    let fixed_height_downsampled : WebpData?
    let fixed_height_small :MP4Data?
    let fixed_height_small_still : ImageSizeData?
    let fixed_height_still : ImageSizeData?
    let fixed_width : MP4Data?
    let fixed_width_downsampled : WebpData?
    let fixed_width_small : MP4Data?
    let fixed_width_small_still : ImageSizeData?
    let fixed_width_still : ImageSizeData?
    let looping : Looping?
    let original_still : ImageSizeData?
    let original_mp4 : OriginalMP4?
    let preview :OriginalMP4?
    let preview_gif : ImageSizeData?
    let preview_webp : ImageSizeData?
    let w480_still : ImageSizeData?
 }
 
public  class Looping : Decodable{
   let mp4_size:String?
   let mp4:String?
 }

public  class OriginalMP4 : Decodable{
    let height: String?
    let width: String?
   let mp4_size:String?
   let mp4:String?
 }

