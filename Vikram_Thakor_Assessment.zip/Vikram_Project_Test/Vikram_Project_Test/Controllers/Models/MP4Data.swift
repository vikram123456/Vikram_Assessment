//
//  File.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class MP4Data : Decodable{
  let height: String?
  let width: String?
  let size: String?
  let url:String?
  let mp4_size:String?
  let mp4:String?
  let webp_size: String?
  let webp:String?
}

