//
//  File.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation
import UIKit

class FileData {
     var image :  UIImage?
     var fileName :  String?
 
    init(image : UIImage, fileName: String) {
         self.image = image
        self.fileName = fileName
      }
}
