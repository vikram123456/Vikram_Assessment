//
//  GIFMainData.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 08/06/22.
//

import Foundation

public class GIFMainData : Decodable{
    let data: [GIFData]?
    let pagination: Pagination?
    let meta: Meta?
}

class Pagination : Decodable {
    var total_count :  Int?
    var count :  Int?
    var offset :  Int?
}

class Meta : Decodable {
    var status :  Int?
    var msg :  String?
    var response_id :  String?
}
