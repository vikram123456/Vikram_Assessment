//
//  User.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation

class User : Decodable{
    let avatar_url : String?
    let banner_image : String?
    let banner_url: String?
    let profile_url: String?
    let username: String?
    let display_name:String?
    let description: String?
    let instagram_url: String?
    let website_url:String?
    let is_verified: Bool?
 }
