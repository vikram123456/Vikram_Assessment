//
//  GIFData.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 08/06/22.
//

import Foundation

public class GIFData : Decodable{
    let type: String?
    let id: String?
    let url: String?
    let slug:String?
    let bitly_gif_url:String?
    let bitly_url:String?
    let embed_url:String?
    let username:String?
    let source:String?
    let title:String?
    let rating:String?
    let content_url:String?
    let source_tld:String?
    let source_post_url:String?
    let is_sticker:Int?
    let import_datetime:String?
    let trending_datetime:String?
    let images:Images?
    let user:User?
    let analytics_response_payload:String?
    let analytics:Analytics?
}

class Analytics : Decodable {
    var onload : AnalyticsData?
    var onclick : AnalyticsData?
    var onsent : AnalyticsData?
}

class AnalyticsData : Decodable {
    var url : String?
}
