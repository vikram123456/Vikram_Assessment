//
//  Helper.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import Foundation
import CryptoKit
import UIKit

class Helper{
    //MARK: URL Methods
    static func getFinalURL(strMethod:String, strExtraParam:String) -> String{
        if strExtraParam.isEmpty {
            return Constants.baseURL + strMethod + "?\(Constants.apikey)=\(Constants.APIKey)&\(Constants.limit)=\(25)&\(Constants.rating)=\("g")"
        }
        return Constants.baseURL + strMethod + "?\(Constants.apikey)=\(Constants.APIKey)&\(Constants.limit)=\(25)&\(Constants.rating)=\("g")&\(Constants.q)=\(strExtraParam)"
       }
    
   //MARK: Custom Methods
    static func getImagesFromLocalDirectory(_ isToFetchFavorites : Bool, isSearch : Bool) ->( [FileData], [String]){
        let folderNameToFetch = isToFetchFavorites ? "Favorites":"GifFiles"
        let documentDirectory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
         let docDirectoryPath = documentDirectory.appendingPathComponent(folderNameToFetch)
        var arrTemp = [FileData]()
        var arrTempFileNames = [String]()
         do {
             let items =  try FileManager.default.contentsOfDirectory(at: docDirectoryPath!, includingPropertiesForKeys: nil)
            if items.count > 0 {
                for imageFile in items{
                    arrTempFileNames.append(imageFile.lastPathComponent)
                    let dataGIFImage = try! Data(contentsOf: URL(string: imageFile.absoluteString)! )
                    let image = UIImage.gifImageWithData(dataGIFImage)!
                    let fileData = FileData(image: image, fileName:imageFile.absoluteString)
                     arrTemp.append(fileData)
                }
            }
            return (arrTemp,arrTempFileNames)
        } catch {
            print("Error while getting images")
        }
   return (arrTemp,arrTempFileNames)

    }
    
   
    
    static func getDocDirPath(_ folderName: String, fileName : String) -> URL{
        let documentDirectory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
         let dirPath = documentDirectory.appendingPathComponent(folderName)
         do
         {
             try FileManager.default.createDirectory(atPath: dirPath!.path, withIntermediateDirectories: true, attributes: nil)
         }catch let error as NSError
         {
             print("Unable to create directory \(error.debugDescription)")
         }
         print("Dir Path = \(dirPath!)")
        return dirPath?.appendingPathComponent(fileName) ?? URL(string: "")!
    }
    
}
