//
//  HomeCollectionViewCell.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import UIKit
 
class GalleryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewProfile: UIImageView!
    @IBOutlet weak var buttonFavorite: UIButton!
 
    override func awakeFromNib() {
    }
    
    override func layoutSubviews() {
        
    }
    
    func setUpCellUI(cell : GalleryCollectionViewCell,  objFileData:  FileData?, indexpath : IndexPath){
        cell.imageViewProfile.image =   objFileData?.image
    }
    
 

    
    func copyFiles(pathFromBundle : String, pathDestDocs: String) {
        let fileManagerIs = FileManager.default
        do {
            let filelist = try fileManagerIs.contentsOfDirectory(atPath: pathFromBundle)
            try? fileManagerIs.copyItem(atPath: pathFromBundle, toPath: pathDestDocs)

            for filename in filelist {
                try? fileManagerIs.copyItem(atPath: "\(pathFromBundle)/\(filename)", toPath: "\(pathDestDocs)/\(filename)")
            }
        } catch {
            print("\nError\n")
        }
    }
    
    
 
}
