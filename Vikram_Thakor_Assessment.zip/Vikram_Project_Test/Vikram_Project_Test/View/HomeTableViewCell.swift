//
//  HomeTableViewCell.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var imageViewProfile: UIImageView!
    @IBOutlet weak var buttonHeart: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    
//    func setUpTableCellUI(cell : HomeTableViewCell, objComic : Comics, indexpath : IndexPath){
//        var strURL = objComic.data?.results![indexpath.item].thumbnail?.path
//         strURL = (strURL ?? "") + ".jpg"
//        cell.imageViewProfile.kf.setImage(with: URL(string: strURL ?? ""))
//         //cell.labelProfileName.text = strName
//        cell.labelTitle.text = "Title : " +  (objComic.data?.results![indexpath.item].title ?? "")
//        cell.labelDesc.text = "Description : " +  (objComic.data?.results![indexpath.item].description?.html2String ?? "")
//        cell.labelFormat.text = "Format : " +  (objComic.data?.results![indexpath.item].format ?? "")
//    }
}
