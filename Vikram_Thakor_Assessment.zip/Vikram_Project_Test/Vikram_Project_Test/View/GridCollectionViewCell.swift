//
//  HomeCollectionViewCell.swift
//  Vikram_Project_Test
//
//  Created by Thakor Vikramji Kishanji on 23/06/22.
//

import UIKit
 
class GridCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewImage: UIView!
    @IBOutlet weak var imageViewProfile: UIImageView!
    @IBOutlet weak var buttonFavorite: UIButton!

    override func awakeFromNib() {
    }
    
    override func layoutSubviews() {
        
    }
    
    func setUpCellUI(cell : GridCollectionViewCell,  objFileData:  FileData, indexpath : IndexPath){
         cell.imageViewProfile.image =   objFileData.image
        cell.buttonFavorite.tintColor = .red
    }
 
}
